<?php 

    require_once('Conectar.php');

class AccionesBD{

        private $conn;

        /**
         * Class Constructor
         * @param    $conn   
         */
        public function __construct(){
            $this->conn = new Conectar();
        }


    public function comprobarConexion(){        
        try{
            $pdo=$this->conn->conexion();
        }catch(Exception $e){
            echo $e->getMessage();
        }
    }

    public function crearTabla($sql,$str){
        $this->conn->setDb($str);
        $pdo=$this->conn->conexion();
        $this->comprobarConexion();
        $count=$pdo->exec($sql);
    /*  var_dump($sql);
        var_dump($count); */
    }

    public function insertarRegistro($sql,$datos=[]){   
        $pdo=$this->conn->conexion();
        $this->comprobarConexion();
        $stmt=$pdo->prepare($sql);
        $stmt->execute($datos);
    /*  var_dump($sql);
        var_dump($stmt);
        print_r($stmt->errorInfo());*/
    }

    public function seleccionarDatos($sql,$str){
        $this->conn->setDb($str);
        $pdo=$this->conn->conexion();
        $this->comprobarConexion();
        $stmt=$pdo->prepare($sql);
        $stmt->execute();
        while($result=$stmt->fetch(PDO::FETCH_ASSOC)){
                $datos[]=$result;
            }
        return $datos;
    }

    public function borrarRegistro($sql,$str,$datos=[]){
        $this->conn->setDb($str);
        $pdo=$this->conn->conexion();
        $this->comprobarConexion();
        $stmt=$pdo->prepare($sql);
        $stmt->execute($datos);
    /*  var_dump($sql);
        var_dump($stmt);
        print_r($stmt->errorInfo());*/
    }


}

 ?>