<?php
include_once('conf.php');
include_once('cabecera_dentro.php');
session_start();
$paginas=isset($_SESSION['paginas'])?"value='".$_SESSION['paginas']."'":' ';
$formato=isset($_SESSION['formato'])?"checked='checked'":' ';
$tinta=isset($_SESSION['tinta'])?"selected='selected'":' ';
$caras=isset($_SESSION['caras'])?"checked='checked'":' ';
$tipoEnc=isset($_SESSION['tipoEnc'])?"selected='selected'":' ';
$metodoEnvio=isset($_SESSION['metodoEnvio'])?"selected='selected'":' ';
?>
<body class="pa">
	<main>
		<section>
			<h3 class="ht" >Creación de Pedido:</h3>
			<div class="centrado">
				<div>
					<form enctype="multipart/form-data" action="VerPedido" method="POST">
						<label><?=LBL_DOCUMENTO ?></label>
						<input type="file" name="fichero" required="required">
						<input type="hidden" name="MAX_FILE_SIZE" value="5900000" />
						<br />
						<label><?=LBL_NR_PAGINAS ?></label>
						<input type="number" name="paginas" id="paginas" class="numero" min="0"  <?=$paginas ?> required="required" />
						<br />
						<div class="formatos">
							<label><?=LBL_FORMATO ?></label>
							<input type="radio" name="formato" value="A4" required="required"
							<?php if(isset($_SESSION['formato'])=='A4'){  ?> <?=$formato ?> <?php } ?>/><label><?=LBL_A4?></label>
							<input type="radio" name="formato" value="A3"
							<?php if(isset($_SESSION['formato'])=='A3'){  ?> <?=$formato ?> <?php } ?> />
							<label><?=LBL_A3?></label>
							<br /><br />
						</div>
						<label><?=LBL_TIPO_COLOR ?></label>
						<select name="tinta" id="tinta">
							<option value="N" <?php if(isset($_SESSION['tinta'])=='N'){  ?><?=$tinta ?> <?php } ?> ><?=LBL_COLOR_NEGRO ?></option>
							<option value="C" <?php if(isset($_SESSION['tinta'])=='C'){  ?><?=$tinta ?> <?php } ?> ><?=LBL_COLOR_COLOR ?></option>
						</select>
						<br /><br />
						<label><?=LBL_CARAS ?></label>
						<br>
						<div class="pad-d">
							<input type="radio" name="caras" value="1" required="required" <?php if(isset($_SESSION['caras'])=='1'){  ?><?=$caras ?><?php }  ?> />
							<label><?=LBL_CARA_UNICA ?></label>
							<br>
							<input type="radio" name="caras" value="2"
							<?php  if(isset($_SESSION['caras'])=='2'){ ?><?=$caras ?><?php } ?> />
							<label><?=LBL_DOBLE_CARA ?></label>
						</div>
						<br />
						<label><?=LBL_TIPO_ENC ?></label>
						<select name="tipoEnc" id="tipoEnc">
							<option value='ninguna' <?php if(isset($_SESSION['tipoEnc'])=='ninguna'){ ?><?=$tipoEnc ?><?php } ?> ><?=LBL_NINGUNO ?></option>
							<option value='libro' <?php if(isset($_SESSION['tipoEnc'])=='libro'){ ?><?=$tipoEnc ?><?php } ?> ><?=LBL_LIBRO ?></option>
							<option value='espiral'
							<?php if(isset($_SESSION['tipoEnc'])=='espiral'){ ?><?=$tipoEnc ?><?php } ?> ><?=LBL_ESPIRAL?></option>
						</select>
						<br />
						<label><?=LBL_METODO ?></label>
						<select name="metodoEnvio" onchange="ca();">
							<option value="punto" <?php	if(isset($_SESSION['metodoEnvio'])=='punto'){ ?><?=$metodoEnvio ?><?php } ?> ><?=LBL_PUNTO ?></option>
							<option value="envio" <?php	if(isset($_SESSION['metodoEnvio'])=='envio'){ ?><?=$metodoEnvio?><?php }?> ><?=LBL_ENVIO ?></option>
						</select>
						<br />
						<div id="eData"></div>
						<input type="submit" class="butonrojo" name="enviar" value="Previsualizar Pedido" />
					</form>
				</div>
			</div>
		</section>
	</main>
	<?php include_once('pie_dentro.php'); ?>